-- 3. feladat

-- 4. feladat

-- 5. feladat

-- 6. feladat

-- 7. feladat

-- 8. feladat

-- 9. feladat

-- 10. feladat

-- 11. feladat

-- 12. feladat