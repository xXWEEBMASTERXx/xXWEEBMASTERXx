﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Operator_PL
{
    internal class Pont
    {
        public int X { get; init; }
        public int Y { get; init; }

        public Pont(int x, int y)
        {
            X = x;
            Y = y;
        }

        public Pont(int x)
        {
            X = x;
            Y = 0;
        }

        public override string ToString()
        {
            return $"X: {X}, Y: {Y}";
        }

        public static Pont operator +(Pont a, Pont b) 
        { 
            return new Pont(a.X+b.X, a.Y+b.Y);
        }

        public static Pont operator +(Pont a, int b)
        {
            return new Pont(a.X+b, a.Y + b);
        }

        public static Pont operator +(int a, Pont b)
        {
            return new Pont(b.X + a, b.Y + a);
        }

        public static Pont operator -(Pont a, Pont b)
        {
            return new Pont(a.X - b.X, a.Y - b.Y);
        }

        public static Pont operator ++(Pont a)
        {
            return new Pont(a.X + 1, a.Y + 1);
        }

        public static Pont operator --(Pont a)
        {
            return new Pont(a.X - 1, a.Y - 1);
        }

        public override int GetHashCode()
        {
            unchecked
            {
                int hash = (int)216613261;
                hash = (hash * 16774391) ^ X.GetHashCode();
                hash = (hash * 16774391) ^ Y.GetHashCode();
                return hash;
            }
        }

        public override bool Equals(object? obj)
        {
            if (obj is null)
            {
                return false;
            }
            if (obj is not Pont masik)
            {
                return false;
            }
            return X==masik.X && Y==masik.Y;
        }

        public static bool operator ==(Pont a, Pont b)
        {
            return a.Equals(b);
        }

        public static bool operator !=(Pont a, Pont b)
        {
            return !a.Equals(b);
        }

        public static implicit operator Pont(int x) 
        {
            return new Pont(x);
        }
        public static implicit operator int(Pont a) 
        {
            return a.X;
        }

        public static explicit operator bool(Pont a) 
        { 
            return (a.X !=0 || a.Y!=0);
        }

    }
}
