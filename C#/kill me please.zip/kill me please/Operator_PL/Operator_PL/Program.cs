﻿/*
 * C#-ban a következő operátorok átdefiniálhatóak:
 * Aritmetikai 2 operandusú operátorok: + - * / %
 * Aritmetikai 1 operandusú operátorok: + - ++ --
 * Bitenkénti logikai operátorok: ~ & | ^ << >>
 * Logikai operátorok közül: !
 * 
 * Az összehasonlító operátorok is átdefiniálhatóak, de csak párban
 * és csak bool visszatérési értékük lehet.
 * Pl.: Ha átdefiniáljuk a kisebb, mint (<) operátort, 
 *      akkor át kell definiálnunk a nagyobb, mint (>) operátor jelentését is.
 * Az átdefiniálható logikai műveletek: < > <= >= == !=
 * 
 */

using Operator_PL;

var p1 = new Pont(1, 3);
var p2 = new Pont(2, 4);
int x = 6;
Console.WriteLine($"p1: {p1}");
Console.WriteLine($"p2: {p2}");
Console.WriteLine($"p1+p2: {p1+p2}");
Console.WriteLine($"p1+x: {p1+x}");
Console.WriteLine($"x+p1: {x + p1}");
Console.WriteLine($"p1-p2: {p1-p2}");
Console.WriteLine($"p1++: {p1++}");
Console.WriteLine($"p1--: {p1--}");
Console.WriteLine($"++p1: {++p1}");
Console.WriteLine($"--p1: {--p1}");

Console.WriteLine(p1.ToString());
int y = p1;
Console.WriteLine(y);
Console.WriteLine((bool)p1);