using Raktarkeszlet.Library;

namespace Raktarkeszlet.Test;

[TestClass]
public class InventoryTests
{
    [TestMethod]
    public void RemoveProductFromInventory_ShouldRemoveProduct()
    {
        InventoryManager manager = new InventoryManager();
        Product productToRemove = new Product { Name = "ToRemove", Quantity = 5 };
        manager.AddProduct(productToRemove);

        manager.RemoveProduct("ToRemove");

        Assert.IsTrue(manager.GetProductQuantity("ToRemove") == 0);
    }

    [TestMethod]
    public void TestAlertFunctionality_ShouldIdentifyProductsBelowThreshold()
    {
        InventoryManager manager = new InventoryManager();
        Product lowStockProduct = new Product { Name = "LowStock", Quantity = 2 };
        manager.AddProduct(lowStockProduct);

        List<Product> belowThresholdProducts = manager.GetProductsBelowThreshold(5);

        Assert.IsTrue(belowThresholdProducts.Count == 1);
        Assert.AreEqual(belowThresholdProducts[0].Name, "LowStock");
    }
    
}
