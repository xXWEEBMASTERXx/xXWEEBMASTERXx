﻿using Raktarkeszlet.Library;

InventoryManager manager = new InventoryManager();

Product newProduct = new Product { Name = "ExampleProduct", Quantity = 15 };
manager.AddProduct(newProduct);

Console.WriteLine($"Quantity of ExampleProduct: {manager.GetProductQuantity("ExampleProduct")}");

manager.RemoveProduct("ExampleProduct");

Console.WriteLine($"Quantity of ExampleProduct after removal: {manager.GetProductQuantity("ExampleProduct")}");
