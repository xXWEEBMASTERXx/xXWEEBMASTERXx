﻿namespace Raktarkeszlet.Library;

public class Product
{
    public string Name { get; set; }
    public int Quantity { get; set; }
}

public class InventoryManager
{
    private List<Product> inventory;

    public InventoryManager()
    {
        inventory = new List<Product>();
    }

    public void AddProduct(Product product)
    {
        inventory.Add(product);
    }

    public void RemoveProduct(string productName)
    {
        Product productToRemove = inventory.Find(p => p.Name == productName);
        if (productToRemove != null)
        {
            inventory.Remove(productToRemove);
        }
    }

    public int GetProductQuantity(string productName)
    {
        Product product = inventory.Find(p => p.Name == productName);
        return product?.Quantity ?? 0;
    }

    public List<Product> GetProductsBelowThreshold(int threshold)
    {
        return inventory.Where(p => p.Quantity < threshold).ToList();
    }

    public void UpdateProductQuantity(string productName, int newQuantity)
    {
        Product productToUpdate = inventory.Find(p => p.Name == productName);
        if (productToUpdate != null)
        {
            productToUpdate.Quantity = newQuantity;
        }
    }
}

