﻿namespace TextUtilities
{
    public enum Color
    {
        Black = 30,
        Red,
        Green,
        Yellow,
        Blue,
        Magenta,
        Cyan,
        White
    }

    public class ProgressBar
    {
        private int width;
        private int minValue;
        private int maxValue;
        private int currentValue;
        private Color primaryBackgroundColor = Color.Black;
        private Color secondaryBackgroundColor = Color.Green;
        private Color primaryForegroundColor = Color.White;
        private Color secondaryForegroundColor = Color.White;
        private string text = "";

        public ProgressBar(int width)
        {
            this.width = width;
            this.minValue = 0;
            this.maxValue = 100;
            this.currentValue = 0;
        }

        public void SetPrimaryBackgroundColor(Color color)
        {
            primaryBackgroundColor = color;
        }

        public void SetSecondaryBackgroundColor(Color color)
        {
            secondaryBackgroundColor = color;
        }

        public void SetPrimaryForegroundColor(Color color)
        {
            primaryForegroundColor = color;
        }

        public void SetSecondaryForegroundColor(Color color)
        {
            secondaryForegroundColor = color;
        }

        public void SetText(string text)
        {
            this.text = text;
        }

        private int CalculateTextPosition()
        {
            int progressBarPadding = (width - 4 - text.Length) / 2;
            return progressBarPadding + 3;
        }

        public void Print()
        {
            int textPosition = CalculateTextPosition();
            Console.SetCursorPosition(textPosition, Console.CursorTop);
            Console.WriteLine(text);

            Console.Write($"-> \u001b[{(int)primaryBackgroundColor};{(int)primaryForegroundColor}m");
            int progressWidth = (int)((double)currentValue / maxValue * (width - 4));
            for (int i = 0; i < progressWidth; i++)
            {
                Console.Write("#");
            }

            for (int i = 0; i < width - 4 - progressWidth; i++)
            {
                Console.Write(" ");
            }

            Console.Write($"{currentValue}%\u001b[0m\n");
        }

        public void Update(int value)
        {
            if (value >= minValue && value <= maxValue)
            {
                currentValue = value;
                Print();
            }
            else
            {
                throw new ArgumentOutOfRangeException("Value is out of range.");
            }
        }

        public void MoveProgressBar()
        {
            for (int i = 0; i <= 100; i += 10)
            {
                Thread.Sleep(500);
                Update(i);
            }
        }
    }
}