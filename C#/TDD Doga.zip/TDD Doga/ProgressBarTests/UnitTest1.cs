using TextUtilities;

namespace ProgressBarTests
{
    [TestClass]
    public class ProgressBarTests
    {
        [TestMethod]
        public void ProgressBar_Print_WithDifferentColors()
        {
            ProgressBar progressBar = new ProgressBar(20);

            progressBar.SetPrimaryBackgroundColor(Color.Blue);
            progressBar.SetSecondaryBackgroundColor(Color.Yellow);
            progressBar.SetPrimaryForegroundColor(Color.White);
            progressBar.SetSecondaryForegroundColor(Color.Cyan);
            progressBar.SetText("Color Test");

            Assert.IsNotNull(progressBar);
            progressBar.Print();
        }

        [TestMethod]
        public void ProgressBar_Print_WithDifferentTexts()
        {
            ProgressBar progressBar = new ProgressBar(20);

            progressBar.SetPrimaryBackgroundColor(Color.Black);
            progressBar.SetSecondaryBackgroundColor(Color.Green);
            progressBar.SetPrimaryForegroundColor(Color.White);
            progressBar.SetSecondaryForegroundColor(Color.White);
            progressBar.SetText("First Text");
            progressBar.Print();

            progressBar.SetText("Second Text");
            progressBar.Print();

            Assert.IsNotNull(progressBar);
        }

        [TestMethod]
        public void ProgressBar_MoveProgressBar()
        {
            ProgressBar progressBar = new ProgressBar(20);

            progressBar.MoveProgressBar();

            Assert.IsNotNull(progressBar);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void ProgressBar_Update_OutOfRange()
        {
            ProgressBar progressBar = new ProgressBar(20);

            progressBar.Update(120);
        }

        [TestMethod]
        public void ProgressBar_Update_InRange()
        {
            ProgressBar progressBar = new ProgressBar(20);

            progressBar.Update(50);

            Assert.IsNotNull(progressBar);
        }
    }
}