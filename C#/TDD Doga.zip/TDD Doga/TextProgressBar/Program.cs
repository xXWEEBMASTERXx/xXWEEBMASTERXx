﻿using TextUtilities;

namespace TextProgressBar
{
    class Program
    {
        static void Main(string[] args)
        {
            ProgressBar progressBar = new ProgressBar(20);

            progressBar.SetPrimaryBackgroundColor(Color.Blue);
            progressBar.SetSecondaryBackgroundColor(Color.Yellow);
            progressBar.SetPrimaryForegroundColor(Color.White);
            progressBar.SetSecondaryForegroundColor(Color.Cyan);
            progressBar.Print();

            progressBar.SetPrimaryBackgroundColor(Color.Black);
            progressBar.SetSecondaryBackgroundColor(Color.Green);
            progressBar.SetPrimaryForegroundColor(Color.White);
            progressBar.SetSecondaryForegroundColor(Color.White);
            progressBar.Print();
            
            progressBar.MoveProgressBar();

            Console.ReadLine();
        }
    }
}