﻿namespace LibraryClasses;

public class Book
{
    public string Title { get; set; }

    public Book(string title)
    {
        Title = title;
    }
}

public class Library
{
    private List<Book> books = new List<Book>();

    public void AddBook(Book book)
    {
        books.Add(book);
    }

    public bool ContainsBook(Book book)
    {
        return books.Contains(book);
    }

    public Book SearchByTitle(string title)
    {
        return books.Find(b => b.Title == title);
    }

    public void DeleteBook(Book book)
    {
        books.Remove(book);
    }

    public List<Book> ListBooks()
    {
        return new List<Book>(books);
    }
}