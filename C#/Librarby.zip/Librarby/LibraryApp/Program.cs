﻿using LibraryClasses;
Console.WriteLine("Console App for Library Management System");

Library library = new Library();
Book book1 = new Book("The Hobbit");
Book book2 = new Book("1984");

library.AddBook(book1);
library.AddBook(book2);

List<Book> books = library.ListBooks();
Console.WriteLine("Books in the library:");
foreach (var book in books)
{
    Console.WriteLine(book.Title);
}