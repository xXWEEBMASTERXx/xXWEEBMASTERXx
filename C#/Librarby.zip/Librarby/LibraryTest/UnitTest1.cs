using LibraryClasses;
namespace Librarby;

[TestClass]
public class LibraryTests
{
    [TestMethod]
    public void AddBook_ShouldAddBookToLibrary()
    {
        Library library = new Library();
        Book newBook = new Book("Az Alkimista");

        library.AddBook(newBook);

        Assert.IsTrue(library.ContainsBook(newBook));
    }

    [TestMethod]
    public void SearchByTitle_ShouldFindBookByTitle()
    {
        Library library = new Library();
        Book existingBook = new Book("Az Alkimista");
        library.AddBook(existingBook);

        Book foundBook = library.SearchByTitle("Az Alkimista");

        Assert.IsNotNull(foundBook);
        Assert.AreEqual(existingBook, foundBook);
    }

    [TestMethod]
    public void DeleteBook_ShouldRemoveBookFromLibrary()
    {
        Library library = new Library();
        Book bookToDelete = new Book("Az Alkimista");
        library.AddBook(bookToDelete);

        library.DeleteBook(bookToDelete);

        Assert.IsFalse(library.ContainsBook(bookToDelete));
    }

    [TestMethod]
    public void ListBooks_ShouldReturnListOfAllBooks()
    {
        Library library = new Library();
        Book book1 = new Book("Az Alkimista");
        Book book2 = new Book("Harry Potter");
        library.AddBook(book1);
        library.AddBook(book2);

        List<Book> bookList = library.ListBooks();

        Assert.AreEqual(2, bookList.Count);
        Assert.IsTrue(bookList.Contains(book1));
        Assert.IsTrue(bookList.Contains(book2));
    }
}