using Klasz_Lájbröri;
namespace Klasz_Lájbröri;
public class Tests
{
[SetUp]
public void Setup()
{
}
[Test]
public void ValidPasswordTest()
{
Assert.IsTrue(Class1.IsValid("Almafa1"));
}
[Test]
public void InvalidPasswordTest()
{
Assert.IsFalse(Class1.IsValid("almafa1"));
Assert.IsFalse(Class1.IsValid("ALMAFA1"));
Assert.IsFalse(Class1.IsValid("Almafa"));
Assert.IsFalse(Class1.IsValid("Eper2"));
}
}