﻿namespace Klasz_Lájbröri;
using System.Text.RegularExpressions;

public class Class1
{
    public static bool IsValid(string password)
    {
        const string regex = @"^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])[a-zA-Z0-9]{6,}$";
        return Regex.IsMatch(password, regex);
    }
}

