﻿Console.Write("adj meg 1 jelszót vaze");
string pwd = Console.ReadLine();