﻿public class CityLakeMapping
{
    public int CityID { get; set; }
    public int LakeID { get; set; }
}
