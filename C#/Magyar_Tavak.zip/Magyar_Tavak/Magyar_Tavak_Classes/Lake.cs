﻿public class Lake
{
    public int ID { get; set; }
    public string Name { get; set; }
    public string Type { get; set; }
    public double Area { get; set; }
    public int WaterCollector { get; set; }
}
