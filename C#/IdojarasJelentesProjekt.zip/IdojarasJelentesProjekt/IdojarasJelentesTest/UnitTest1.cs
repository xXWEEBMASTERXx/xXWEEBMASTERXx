using IdojarasJelentesLib;
namespace IdojarasJelentesTest;

[TestClass]
public class IdojarasJelentesTest
{
    [TestMethod]
    public void HighTemperature_Classification_ShouldReturnVeryHot()
    {
        var idojarasJelentes = new IdojarasJelentes();

        var classification = idojarasJelentes.IdojarasOsztalyozas(35, 50, 10);

        Assert.AreEqual("Nagyon meleg", classification);
    }

    [TestMethod]
    public void ModerateWeather_Classification_ShouldReturnModerate()
    {
        var idojarasJelentes = new IdojarasJelentes();

        var classification = idojarasJelentes.IdojarasOsztalyozas(20, 50, 5);

        Assert.AreEqual("Mérsékelt", classification);
    }

    [TestMethod]
    public void VeryColdWeather_Classification_ShouldReturnVeryCold()
    {
        var idojarasJelentes = new IdojarasJelentes();

        var classification = idojarasJelentes.IdojarasOsztalyozas(-10, 30, 35);

        Assert.AreEqual("Nagyon hideg", classification);
    }

    [TestMethod]
    public void StormyWeather_Classification_ShouldReturnStormy()
    {
        var idojarasJelentes = new IdojarasJelentes();

        var classification = idojarasJelentes.IdojarasOsztalyozas(10, 60, 80);

        Assert.AreEqual("Viharos", classification);
    }
}
