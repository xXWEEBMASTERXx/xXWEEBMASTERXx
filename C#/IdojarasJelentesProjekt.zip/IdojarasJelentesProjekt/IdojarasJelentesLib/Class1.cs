﻿namespace IdojarasJelentesLib;

public class IdojarasJelentes
{
    public string IdojarasOsztalyozas(double homerseklet, double paratartalom, double szelsebesseg)
    {
        if (homerseklet > 30)
        {
            return "Nagyon meleg";
        }
        else if (homerseklet >= 10 && homerseklet <= 30 && paratartalom >= 30 && paratartalom <= 70 && szelsebesseg < 40)
        {
            return "Mérsékelt";
        }
        else if (homerseklet < 0 && paratartalom < 40 && szelsebesseg > 30)
        {
            return "Nagyon hideg";
        }
        else if (szelsebesseg > 60)
        {
            return "Viharos";
        }
        else
        {
            return "Egyéb";
        }
    }
}
