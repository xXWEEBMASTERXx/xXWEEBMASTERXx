function korOsztaly() {
    var kor = prompt("Kérem adja meg az életkorát:");
    if (kor < 6) {
        alert("Az adott személy iskola előtt áll.");
    } else if (kor >= 6 && kor < 14) {
        alert("Az adott személy általános iskolába jár.");
    } else if (kor >= 14 && kor < 18) {
        alert("Az adott személy középiskolába jár.");
    } else {
        alert("Az adott személy már befejezte a középiskolát.");
    }
}

// 2. feladat
function legtobbSzamjegy() {
    var szam1 = parseInt(prompt("Kérem adja meg az első számot:"));
    var szam2 = parseInt(prompt("Kérem adja meg a második számot:"));
    var szam3 = parseInt(prompt("Kérem adja meg a harmadik számot:"));

    var szamjegySzam1 = szam1.toString().length;
    var szamjegySzam2 = szam2.toString().length;
    var szamjegySzam3 = szam3.toString().length;

    if (szamjegySzam1 >= szamjegySzam2 && szamjegySzam1 >= szamjegySzam3) {
        alert("Az első szám a legtöbb számjegyből álló.");
    } else if (szamjegySzam2 >= szamjegySzam1 && szamjegySzam2 >= szamjegySzam3) {
        alert("A második szám a legtöbb számjegyből álló.");
    } else {
        alert("A harmadik szám a legtöbb számjegyből álló.");
    }
}

// 3. feladat
function haromszogTipus() {
    var a = parseFloat(prompt("Kérem adja meg az 'a' oldal hosszát:"));
    var b = parseFloat(prompt("Kérem adja meg a 'b' oldal hosszát:"));
    var c = parseFloat(prompt("Kérem adja meg a 'c' oldal hosszát:"));

    var c2 = c * c;
    var a2 = a * a;
    var b2 = b * b;

    if (c2 === a2 + b2) {
        alert("A háromszög derékszögű.");
    } else if (c2 < a2 + b2) {
        alert("A háromszög hegyesszögű.");
    } else {
        alert("A háromszög tompaszögű.");
    }
}

// 4. feladat
function oszthatoSzamok() {
    var szam = parseInt(prompt("Kérem adja meg a számot:"));

    for (var i = 1; i < 500; i++) {
        if (i % szam === 0) {
            console.log(i);
        }
    }
}

// 5. feladat
function parosSzamokVisszafel() {
    var szam1 = parseInt(prompt("Kérem adja meg az első számot:"));
    var szam2 = parseInt(prompt("Kérem adja meg a második számot:"));

    var kezdo = Math.max(szam1, szam2);
    var veg = Math.min(szam1, szam2);

    for (var i = kezdo; i >= veg; i--) {
        if (i % 2 === 0) {
            console.log(i);
        }
    }
}

// 6. feladat
function haromszogSzamok() {
    var n = 1;
    var haromszogSzam = 0;

    while (haromszogSzam < 1000) {
        haromszogSzam = (n * (n + 1)) / 2;
        if (haromszogSzam < 1000) {
            console.log(haromszogSzam);
        }
        n++;
    }
}

document.write("<button onclick='korOsztaly()'>1. feladat</button>");
document.write("<button onclick='legtobbSzamjegy()'>2. feladat</button>");
document.write("<button onclick='haromszogTipus()'>3. feladat</button>");
document.write("<button onclick='oszthatoSzamok()'>4. feladat</button>");
document.write("<button onclick='parosSzamokVisszafel()'>5. feladat</button>");
document.write("<button onclick='haromszogSzamok()'>6. feladat</button>");
