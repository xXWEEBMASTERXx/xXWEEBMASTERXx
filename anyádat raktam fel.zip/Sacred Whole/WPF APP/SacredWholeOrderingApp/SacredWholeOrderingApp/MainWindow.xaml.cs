﻿using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Collections.ObjectModel;

namespace SacredWholeOrderingApp
{
    public partial class MainWindow : Window
    {
        private ObservableCollection<MenuItem> menuItems;
        private ObservableCollection<Order> cartItems;

        public class Order
        {
            public MenuItem Item { get; set; }
            public int Quantity { get; set; }

            public string DisplayText => $"{Quantity} x {Item.Name} - {Item.Price * Quantity} HUF";
        }

        public MainWindow()
        {
            InitializeComponent();

            menuItems = new ObservableCollection<MenuItem>
        {
                new MenuItem { Name = "Potion of Pumpkin Spice", Price = 1000, Category = "Enchanted Elixirs" },
                new MenuItem { Name = "Dragon's Breath Brew", Price = 1200, Category = "Enchanted Elixirs" },
                new MenuItem { Name = "Stardust Sparkler", Price = 8000, Category = "Enchanted Elixirs" },
                new MenuItem { Name = "Moonlit Nectar", Price = 1500, Category = "Enchanted Elixirs" },
                new MenuItem { Name = "Witch's Brew Blend", Price = 1800, Category = "Enchanted Elixirs" },
                new MenuItem { Name = "Frostfire Elixir", Price = 1400, Category = "Enchanted Elixirs" },
                new MenuItem { Name = "Spectral Sip", Price = 2000, Category = "Enchanted Elixirs" },
                new MenuItem { Name = "Celestial Zest Elixir", Price = 2500, Category = "Enchanted Elixirs" },

                new MenuItem { Name = "Fairy Tale Feast", Price = 25000, Category = "Mystical Morsels" },
                new MenuItem { Name = "Unicorn's Delight Salad", Price = 18000, Category = "Mystical Morsels" },
                new MenuItem { Name = "Phoenix Flame Grilled Skewers", Price = 22000, Category = "Mystical Morsels" },
                new MenuItem { Name = "Mermaid's Siren Sushi", Price = 2000, Category = "Mystical Morsels" },
                new MenuItem { Name = "Enchanted Forest Quiche", Price = 15000, Category = "Mystical Morsels" },
                new MenuItem { Name = "Starlight Soufflé", Price = 3000, Category = "Mystical Morsels" },
                new MenuItem { Name = "Pixie Puffs", Price = 1200, Category = "Mystical Morsels" },
                new MenuItem { Name = "Midnight Munchies Platter", Price = 2800, Category = "Mystical Morsels" },

                new MenuItem { Name = "Magician's Feast Platter", Price = 40000, Category = "Fantastical Feast" },
                new MenuItem { Name = "Enchanted Woodland Pasta", Price = 35000, Category = "Fantastical Feast" },
                new MenuItem { Name = "Dragon's Ember Roast Chicken", Price = 28000, Category = "Fantastical Feast" },
                new MenuItem { Name = "Sorcerer's Cauldron Stew", Price = 32000, Category = "Fantastical Feast" },
                new MenuItem { Name = "Mythical Mushroom Risotto", Price = 38000, Category = "Fantastical Feast" },
                new MenuItem { Name = "Griffin Gravy Pot Pie", Price = 45000, Category = "Fantastical Feast" },
                new MenuItem { Name = "Crystalized Chalice Casserole", Price = 50000, Category = "Fantastical Feast" },
                new MenuItem { Name = "Starstruck Steak", Price = 55000, Category = "Fantastical Feast" },
        };
            foodListBox.ItemsSource = null;

            cartItems = new ObservableCollection<Order>();

            cartListBox.ItemsSource = cartItems;

            cartItems.CollectionChanged += CartItems_CollectionChanged;

            categoryTreeView.SelectedItemChanged += categoryTreeView_SelectedItemChanged;
        }
        private void CartItems_CollectionChanged(object sender, System.Collections.Specialized.NotifyCollectionChangedEventArgs e)
        {
            UpdateCartItemCount();
        }

        private void UpdateCartItemCount()
        {
            int itemCount = cartItems.Sum(order => order.Quantity);
        }

        private void categoryTreeView_SelectedItemChanged(object sender, RoutedPropertyChangedEventArgs<object> e)
        {
            TreeViewItem selectedCategory = (TreeViewItem)categoryTreeView.SelectedItem;

            if (selectedCategory != null)
            {
                string categoryName = selectedCategory.Header.ToString();

                IEnumerable<MenuItem> categoryItems = menuItems.Where(item => item.Category == categoryName);

                foodListBox.ItemsSource = categoryItems.ToList();
            }
            else
            {
                foodListBox.ItemsSource = null;
            }
        }

        private void AddToCart_Click(object sender, RoutedEventArgs e)
        {
            MenuItem selectedMenuItem = (MenuItem)foodListBox.SelectedItem;

            if (selectedMenuItem != null)
            {
                Order existingOrder = cartItems.FirstOrDefault(order => order.Item == selectedMenuItem);

                if (existingOrder != null)
                {
                    existingOrder.Quantity++;
                }
                else
                {
                    Order newOrder = new Order { Item = selectedMenuItem, Quantity = 1 };
                    cartItems.Add(newOrder);
                }
            }
        }
        private void Purchase_Click(object sender, RoutedEventArgs e)
        {
            CartWindow cartWindow = new CartWindow(cartItems);
            cartWindow.ShowDialog();


            if (cartWindow.PurchaseConfirmed)
            {
                PurchaseWindow purchaseWindow = new PurchaseWindow();
                purchaseWindow.ShowDialog();

                Close();
            }
        }



        public class MenuItem
        {
            public string Name { get; set; }
            public decimal Price { get; set; }
            public string Category { get; set; }
        }
    }
}