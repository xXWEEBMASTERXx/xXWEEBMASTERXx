﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;
using System.Collections.ObjectModel;

namespace Magyar_Tavak
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        public class Telepules : ObservableCollection<string>
        {
            public Telepules()
            {
                StreamReader sr = new("telepulesgps.txt");
                string sor = sr.ReadLine();
                string[] telepulesek = new string[3138];
                string[] lenght = new string[3138];
                string[] widht = new string[3138];
                while (!sr.EndOfStream)
                {
                    string[] sor2 = sor.Split("\t");
                    Console.WriteLine(sor2[1]);
                    sor = sr.ReadLine();
                    telepulesek.Append(sor2[1]);
                    lenght.Append(sor2[2]);
                    widht.Append(sor2[3]);
                }
                sr.Close();
                for (int i = 0; i < telepulesek.Length; i++)
                {
                    Add(telepulesek[i].ToString());
                }
            }
        }
    }
}
