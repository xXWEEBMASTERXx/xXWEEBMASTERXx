﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Csokigyar
{
    internal sealed class PremiumCsoki
    {
        public PremiumCsoki(string csokifajta, IEnumerable<string> alapanyagok, int kakaoTartalom)
        {
            
        }
    }
}
